package App.controller;

public interface ControllerInterface {

    public void session() throws Exception;

}
